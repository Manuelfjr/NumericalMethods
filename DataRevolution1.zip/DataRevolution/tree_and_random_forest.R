#banco de dados 

library(rpart)
library(rpart.plot)
library(randomForest)

#mudança de diretório
setwd("~/Área de Trabalho/Data revolution")

#leitura dos dados


dados<- read.csv("campanha_venda_model.csv", header = T)
head(dados)
dim(dados)

rtree_fit <- rpart(Campanha ~ Engaj+Idade+Regiao+Tipo_Cliente+Sexo+Tempo_relacionamento+Status+Total_gasto, data = dados)
rpart.plot(rtree_fit)
text(rtree_fit)

#random forest

rf<- randomForest(Campanha ~ Engaj+Idade+Regiao+Tipo_Cliente+Sexo+
                    Tempo_relacionamento+Status+Total_gasto, data = dados)
