#limpando todos os objetos

rm(list=ls())

#pacotes 

library(dplyr)
library(rpart)
library(rpart.plot)
library(randomForest)

#mudança de diretório
setwd("~/Área de Trabalho/Data revolution")

#leitura dos dados


dados<- read.csv("campanha_venda_model.csv", header = T)
head(dados)
dim(dados)

# Separar os dados em treino e teste
set.seed(112)
.data <- c("training", "test","validation") %>%
  sample(nrow(dados), replace = T) %>%
  split(dados, .)
.data

#dados de treino
data.train<- .data$training
dim(data.train)
head(data.train)

#porcentagem de compra
sum(data.train$Campanha)/length(data.train$Campanha)

rtree_fit.train <- rpart(Campanha ~ Idade+Engaj+Sexo+Regiao+Regiao_int+Tipo_Cliente
                         +Total_gasto+Tempo_relacionamento+Status, data = data.train)
rpart.plot(rtree_fit.train)

######################
#  RandomForest
#####################

features<- c('Idade', 'Engaj','Sexo','Tipo_Cliente',
             'Total_gasto','Tempo_relacionamento','Status')
rf.train<- data.train[,features]

rf.data<- rfImpute(x = rf.train,
                        y = data.train$Campanha,
                        importance = TRUE,
                        ntree = 100)
rf.data[,-1]

rf.model<- randomForest(x = rf.data$Sexo,
                    y = data.train$Campanha,
                    importance = T,
                    ntree = 100)

#verifica quais features foram mais relevantes

varImpPlot(rf.model)

#########################

#modelo de regressão
modelo.logistic<- glm(Campanha~Idade+Engaj+Sexo+Tempo_relacionamento,family=binomial(link="logit"), 
                      data = data.train)
modelo.logistic
summary(modelo.logistic)
