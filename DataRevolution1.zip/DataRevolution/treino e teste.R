#banco de dados 
# Pacotes a serem utilizados neste post
library(dplyr)
library(rpart)
library(rpart.plot)
library(randomForest)

#mudança de diretório
setwd("~/Área de Trabalho/Data revolution")

#leitura dos dados


dados<- read.csv("campanha_venda_model.csv", header = T)
head(dados)
dim(dados)

# Separar os dados em treino e teste
set.seed(112)
.data <- c("training", "test","validation") %>%
  sample(nrow(dados), replace = T) %>%
  split(dados, .)
.data

#dados de teste
data.test<- .data$test
dim(data.test)
rtree_fit.test <- rpart(Campanha ~ ., data = data.test)
rpart.plot(rtree_fit.test)

sum(data.test$Campanha)/length(data.test$Campanha)

#dados de treino
data.train<- .data$training
dim(data.train)
head(data.train)
rtree_fit.train <- rpart(Campanha ~ Idade+Engaj+Sexo+Regiao+Regiao_int+Tipo_Cliente
                         +Total_gasto+Tempo_relacionamento+Status, data = data.train)
rpart.plot(rtree_fit.train)

sum(data.train$Campanha)/length(data.train$Campanha)

#dados de validação
data.valida<- .data$validation
dim(data.valida)
rtree_fit.valida<- rpart(Campanha ~ Idade+Engaj+Sexo, data = data.valida)
rpart.plot(rtree_fit.valida)

sum(data.valida$Campanha)/length(data.valida$Campanha)



