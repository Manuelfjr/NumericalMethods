# Pacotes a serem utilizados neste post
library(dplyr)
library(readr)
library(rpart)
library(rpart.plot)
library(xtable)
library(randomForest)

# Lendo os dados do titanic a partir de repositório, selecionando e tratando variáveis
titanic <- "https://gitlab.com/dados/open/raw/master/titanic.csv" %>%
  read_csv %>% 
  select(survived, embarked, sex, 
         sibsp, parch, fare) %>%  
  mutate(
    survived = as.factor(survived),
    embarked = as.factor(embarked),
    sex = as.factor(sex)) 

# Mostrando o head dos dados
print(xtable(head(titanic)), type = "html", digits = 2, include.rownames=FALSE)

# Mostrando o head dos dados
print(xtable(head(titanic)), type = "html", digits = 2, include.rownames=FALSE)

# Separar os dados em treino e teste
set.seed(110)
.data <- c("training", "test") %>%
  sample(nrow(titanic), replace = T) %>%
  split(titanic, .)
.data

data.train<- .data$training

# Criar a árvore de decisão
rtree_fit3 <- rpart(survived ~ ., data.train)
rpart.plot(rtree_fit3)

######################
#  RandomForest
#####################

features<- c('embarked','sex', 'sibsp', 'parch','fare')
rf.train<- data.train[,features]

rf.model<- randomForest(x = rf.train,
                        y = data.train$survived,
                        importance = T,
                        ntree = 100)

#verifica quais features foram mais relevantes

varImpPlot(rf.model)